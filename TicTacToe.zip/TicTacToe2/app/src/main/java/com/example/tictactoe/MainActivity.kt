package com.example.tictactoe

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var player = true // true for X, false for O
    private var boardStatus = Array(3) { IntArray(3) }
    private lateinit var board: Array<Array<Button>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        board = arrayOf(
            arrayOf(findViewById(R.id.button1), findViewById(R.id.button2), findViewById(R.id.button3)),
            arrayOf(findViewById(R.id.button4), findViewById(R.id.button5), findViewById(R.id.button6)),
            arrayOf(findViewById(R.id.button7), findViewById(R.id.button8), findViewById(R.id.button9))
        )

        for (i in 0..2) {
            for (j in 0..2) {
                board[i][j].setOnClickListener {
                    onClick(it as Button, i, j)
                }
            }
        }

        initializeBoardStatus()

        findViewById<Button>(R.id.resetButton).setOnClickListener {
            resetBoard()
        }
    }

    private fun onClick(button: Button, row: Int, col: Int) {
        if (boardStatus[row][col] == -1) {
            boardStatus[row][col] = if (player) 1 else 0
            button.text = if (player) "X" else "O"
            button.isEnabled = false
            player = !player
        }

        if (checkWinner()) {
            val inflater = layoutInflater
            val dialogView = inflater.inflate(R.layout.dailog, null)
            val winnerText = dialogView.findViewById<TextView>(R.id.input)
            val playAgainButton = dialogView.findViewById<Button>(R.id.playAgainButton)

            //winnerText.text = "Player 1(${if (!player) "X" else "O"}) Is Winner!"

            if(!player)
            {
                winnerText.text = "Player 1 (X) is Winner...!"
            }
            else
            {
                winnerText.text = "Player 2 (O) is Winner...!"
            }

            val alertDialogBuilder = AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)

            val alertDialog = alertDialogBuilder.create()

            playAgainButton.setOnClickListener {
                resetBoard()
                alertDialog.dismiss()
            }
            alertDialog.show()
            disableButtons()
        }
        else if(CheckTie())
        {
            val inflater = layoutInflater
            val dialogView = inflater.inflate(R.layout.dailog, null)
            val winnerText = dialogView.findViewById<TextView>(R.id.input)
            val playAgainButton = dialogView.findViewById<Button>(R.id.playAgainButton)

            winnerText.text = "Opps..! Game Is Tie"

            val alertDialogBuilder = AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)

            val alertDialog = alertDialogBuilder.create()

            playAgainButton.setOnClickListener {
                resetBoard()
                alertDialog.dismiss()
            }
            alertDialog.show()
            disableButtons()
        }
    }

    private fun CheckTie(): Boolean {
        for(row in boardStatus)
        {
            for(cell in row)
            {
                if(cell == -1)
                {
                    return false
                }
            }
        }
        return true
    }

    private fun checkWinner(): Boolean {
        // Check rows
        for (i in 0..2) {
            if (boardStatus[i][0] == boardStatus[i][1] && boardStatus[i][1] == boardStatus[i][2] && boardStatus[i][0] != -1) {
                return true
            }
        }

        // Check columns
        for (i in 0..2) {
            if (boardStatus[0][i] == boardStatus[1][i] && boardStatus[1][i] == boardStatus[2][i] && boardStatus[0][i] != -1) {
                return true
            }
        }

        // Check diagonals
        if (boardStatus[0][0] == boardStatus[1][1] && boardStatus[1][1] == boardStatus[2][2] && boardStatus[0][0] != -1) {
            return true
        }

        if (boardStatus[0][2] == boardStatus[1][1] && boardStatus[1][1] == boardStatus[2][0] && boardStatus[0][2] != -1) {
            return true
        }

        return false
    }

    private fun disableButtons() {
        for (i in 0..2) {
            for (j in 0..2) {
                board[i][j].isEnabled = false
            }
        }
    }

    private fun initializeBoardStatus() {
        for (i in 0..2) {
            for (j in 0..2) {
                boardStatus[i][j] = -1
                board[i][j].text = ""
                board[i][j].isEnabled = true
            }
        }
    }

    private fun resetBoard() {
        player = true
        initializeBoardStatus()
    }
}
